var log = console.log.bind(console);
